﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="PrintGatePass.aspx.cs" Inherits="PrintGatePass" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Print Gate Pass</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0" />
    <link href="../css/googleapis.css" rel="stylesheet" type="text/css" />
    <link href="../css/Style.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="../css/bootstrap.css" />
    <link rel="stylesheet" href="../css/plugins_1.css" />
    <link rel="stylesheet" href="../css/main_1.css" />
    <link rel="stylesheet" href="../css/themes.css" />
    <script src="js/jquery.js"></script>
    <script src="js/modernizr-2.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>
</head>
<body>
    <form id="form1" runat="server">
        <div id="divpass">

            <div id="page-container">
                <div id="main-container">
                    <header class="navbar navbar-default">
                        <div class="nav navbar-nav-custom navbar-nav-custom-right">

                            <div class="header-top-left">
                                <asp:Label ID="lblUserName" runat="server">
                                </asp:Label>
                            </div>
                        </div>
                    </header>
                    <div style="min-height: 200px;" id="page-content">
                        <div class="row"><img src="images/logochat.png" width="100" height="60"/></div>
                        <div class="row">

                            <div class="col-md-12">
                                <div class="block">
                                    <div class="block-title">
                                        <h2>Gate Pass</h2>

                                        <span style="float: right;">
                                            <asp:HiddenField ID="HfId" runat="server" />
                                            <asp:Label ID="lblmsg" runat="server" CssClass="label-display"></asp:Label>
                                        </span>
                                    </div>
                                    <div class="form-horizontal form-bordered">
                                        <div class="form-group" style="border-bottom: none;">

                                            <table border="0">
                                                <tr>
                                                    <td>Visitor Name:</td>
                                                    <td>
                                                        <asp:Label runat="server" ID="lblVisitorName"></asp:Label>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>Mobile Number:</td>
                                                    <td>
                                                        <asp:Label runat="server" ID="lblMobileNumber"></asp:Label>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>Contact Person Name:</td>
                                                    <td>
                                                        <asp:Label runat="server" ID="lblContactPerson"></asp:Label>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>Purpose:</td>
                                                    <td>
                                                        <asp:Label runat="server" ID="lblPurpose"></asp:Label>
                                                    </td>
                                                </tr>
                                            </table>

                                            <%-- <div class="col-md-12">


                                                <label class="control-label col-md-2">
                                                    Visitor Name
                                                </label>
                                                <div class="col-md-3">
                                                    <asp:TextBox ID="txtVisitorName" placeholder="Enter Full Name"
                                                        CssClass="form-control" runat="server"></asp:TextBox>

                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <label class="control-label col-md-2">
                                                    Mobile Number
                                                </label>
                                                <div class="col-md-3">
                                                    <asp:TextBox ID="txtMobileNumber" placeholder="Enter Mobile Number" MaxLength="10"
                                                        CssClass="form-control" runat="server"></asp:TextBox>
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <label class="control-label col-md-2">
                                                    Contact Person Name
                                                </label>
                                                <div class="col-md-3">
                                                    <asp:TextBox ID="txtContactPersonName" placeholder="Enter Contact Person Name"
                                                        CssClass="form-control" runat="server"></asp:TextBox>
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <label class="control-label col-md-2">
                                                    Purpose
                                                </label>
                                                <div class="col-md-3">
                                                    <asp:TextBox ID="txtPurpose" placeholder="Enter Contact Person Name"
                                                        CssClass="form-control" runat="server"></asp:TextBox>
                                                </div>
                                            </div>--%>
                                        </div>
                                        <div style="clear: both; height: 15px;">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">

                    <div class="col-md-5">
                        <button class="btn btn-sm btn-primary" id="BtnSave" onclick="printDiv()">Print</button>
                        <div style="clear: both; height: 15px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <script>
        function printDiv() {
            debugger
            let mywindow = window.open('', '', 'height=650,width=900,top=100,left=150');

            mywindow.document.write('<html><head><title>Gate Pass</title>');
            mywindow.document.write('</head><body>');
            mywindow.document.write(document.getElementById('page-content').innerHTML);
            mywindow.document.write('</body></html>');

            mywindow.document.close(); // necessary for IE >= 10

            mywindow.print();

            return true;
        }
    </script>
</body>
</html>
