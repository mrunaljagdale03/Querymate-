﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Common/MasterPage.master" AutoEventWireup="true" CodeFile="DashBoard.aspx.cs" Inherits="Common_DashBoard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" Runat="Server">
    <div>

        <style>
            .chatbot-container {
    position: fixed;
    bottom: 20px; /* Adjust as needed */
    right: 20px;  /* Adjust as needed */
    z-index: 1000; /* Ensure it's above other content */
}

.chatbot-image {
    width: 250px;  /* Adjust to the size of your chatbot image */
    height: auto;
    cursor: pointer; /* Optional: makes the image clickable */
}
        </style>


    <img src="../images/ane.gif" width="100%" height="864"/>
         <div class="chatbot-container">
       <a href="#"> <img src="../images/an2.gif" alt="Chatbot" class="chatbot-image"></a>
       <%--<a href="../Student/Chatbot.aspx"> <img src="../images/an2.gif" alt="Chatbot" class="chatbot-image"></a>--%>
    </div>

    </div>
</asp:Content>

