﻿using System;

public partial class Common_MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Role"] == null)
            {
                Response.Redirect("~/SessionExpired.aspx");
            }
        }
        HideShowMenu();
    }

    private void HideShowMenu()
    {
        if (Session["Role"]==null)
        {
            Response.Redirect("~/SessionExpired.aspx");
        }
        if (Session["Role"].ToString().Equals("Admin"))
        {
            lblUserName.Text = Session["UserName"].ToString();
            AddQuestionsId.Visible = true;
            AddNoticeId.Visible = true;
            InvalidQuestionId.Visible = true;

            ChatbotId.Visible = false;
            NoticeBoardId.Visible = false;
            NewPendingQuestionId.Visible = false;
        }
        else if (Session["Role"].ToString().Equals("Student"))
        {
            lblUserName.Text = Session["UserName"].ToString();
            AddQuestionsId.Visible = false;
            AddNoticeId.Visible = false;
            InvalidQuestionId.Visible = false;

            ChatbotId.Visible = true;
            NoticeBoardId.Visible = true;
            NewPendingQuestionId.Visible = true;
        }
    }
    protected void LinkBtnLogout_Click(object sender, EventArgs e)
    {
        if (Session["Role"].ToString().Equals("Admin"))
        {
            Response.Redirect("~/Default.aspx");
        }
        else
        {
            Response.Redirect("~/StudentLogin.aspx");
        }
    }
}
