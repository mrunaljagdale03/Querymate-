﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Web.UI.WebControls;

public partial class Student_StudentRegistration : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);
    SendEmail sendEmail = new SendEmail();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (CheckForInternetConnection()==false)
            {
                lblmsg.ForeColor = Color.Red;
                lblmsg.Text = "Please Check Your Internet COnnection";
                return;
            }
            string data = UserExist();
            if (data=="AlreadyActivated")
            {
                lblmsg.ForeColor = Color.Red;
                lblmsg.Text = "Email already exist and active"
                return;
            }
            else if (data == "NotActive")
            {
                DivAccountActivation.Visible = true;
                return;
            }
           

            con.Open();
            string otp = RandomString(4);
            string password= RandomString(8);
            SqlCommand cmd = new SqlCommand("Insert into StudentRegistration(StudentName,Address,MobileNumber,Email,Passwords,OTP,IsActive) values('" + txtStudentName.Text.Trim() + "','" + txtAddress.Text.Trim() + "','" + txtMobileNumber.Text.Trim() + "','" + txtEmail.Text.Trim() + "','" + password + "','" + otp + "',0)", con);
            int result = cmd.ExecuteNonQuery();
            if (result >= 0)
            {
                lblmsg.ForeColor = Color.Green;
                lblmsg.Text = "OTP sent to your registered emailid";
                con.Close();
                cmd.Dispose();
                sendEmail.Send(txtEmail.Text.Trim(), "OTP activation for QUERYMATE", "Your activation OTP is " + otp);
                DivAccountActivation.Visible = true;
            }
            else
            {
                lblmsg.ForeColor = Color.Red;
                lblmsg.Text = "Registration Failed";
            }
        }
        catch (Exception ex)
        {

            lblmsg.ForeColor = Color.Red;
            lblmsg.Text = ex.Message;
        }
        
    }

    public static bool CheckForInternetConnection()
    {
        try
        {
            using (var client = new WebClient())
            using (client.OpenRead("http://google.com"))
                return true;
        }
        catch
        {
            return false;
        }
    }

    private static Random random = new Random();
    private string RandomString(int length)
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        return new string(Enumerable.Repeat(chars, length).Select(s => s[random.Next(s.Length)]).ToArray());
    }

    void Clear()
    {
      
        txtStudentName.Text = "";
        txtAddress.Text = "";
        txtMobileNumber.Text = "";
        txtEmail.Text = "";
        BtnSave.Text = "Save";
        txtStudentName.Focus();
        DivAccountActivation.Visible = false;
    }

    protected void BtnClear_Click(object sender, EventArgs e)
    {
        Clear();
        lblmsg.Text = "";
    }

    protected void btnActivate_Click(object sender, EventArgs e)
    {
        try
        {
            string data = ValidateOTP(txtOTP.Text.Trim());
            if (data == "invalid")
            {
                lblmsg.ForeColor = Color.Red;
                lblmsg.Text = "OTP is invalid. Please try again..!";
                return;
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("Update StudentRegistration Set IsActive=1 where Email='" + txtEmail.Text.Trim() + "'", con);
            int result = cmd.ExecuteNonQuery();
            if (result >= 0)
            {
                con.Close();
                cmd.Dispose();
                sendEmail.Send(txtEmail.Text.Trim(), "Successfully Register for KKW QUEYMATE", "Your Login ID is " + txtEmail.Text.Trim() + " and Password is " + data);
                Response.Redirect("~/Student/ThankYou.aspx");
            }
            else
            {
                lblmsg.ForeColor = Color.Red;
                lblmsg.Text = "Record Failed To Inserted";
            }
        }
        catch (Exception ex)
        {

            lblmsg.ForeColor = Color.Red;
            lblmsg.Text = ex.Message;
        }
    }

    string ValidateOTP(string otp)
    {
        SqlDataAdapter da = new SqlDataAdapter("Select OTP,Passwords from StudentRegistration where Email='" + txtEmail.Text.Trim() + "'", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count>0)
        {
            if (dt.Rows[0]["OTP"].Equals(otp))
            {
                return dt.Rows[0]["Passwords"].ToString();
            }
        }
        return "invalid";
    }

    string UserExist()
    {
        SqlDataAdapter da = new SqlDataAdapter("Select * from StudentRegistration where Email='" + txtEmail.Text.Trim() + "'", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            if (dt.Rows[0]["Email"].ToString()==txtEmail.Text.Trim() &&  Convert.ToBoolean(dt.Rows[0]["IsActive"]) == true)
            {
                return "AlreadyActivated";
            }
            else if(dt.Rows[0]["Email"].ToString() == txtEmail.Text.Trim() && Convert.ToBoolean(dt.Rows[0]["IsActive"]) == false)
            {
                sendEmail.Send(txtEmail.Text.Trim(), "Activation OTP for QURYMATE", "Your QuryMate activation OTP is " + dt.Rows[0]["OTP"].ToString());
                return "NotActive";
            }
        }
        return "NotExist";
    }

    protected void btnGotoLogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/StudentLogin.aspx");
    }
}