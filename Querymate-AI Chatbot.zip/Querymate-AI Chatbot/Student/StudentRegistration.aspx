﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="StudentRegistration.aspx.cs" Inherits="Student_StudentRegistration" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Student Registration</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0" />
    <link href="../css/googleapis.css" rel="stylesheet" type="text/css" />
    <link href="../css/Style.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="../css/bootstrap.css" />
    <link rel="stylesheet" href="../css/plugins_1.css" />
    <link rel="stylesheet" href="../css/main_1.css" />
    <link rel="stylesheet" href="../css/themes.css" />
    <script src="../js/jquery.js"></script>
    <script src="../js/modernizr-2.js"></script>
    <style type="text/css">
        #fi #fic {
            margin-right: 100px !important;
        }

        #fi #rh {
            margin-left: -115px !important;
            width: 95px !important;
        }

        #fi .rh {
            display: none !important;
        }

        body:not(.xE) div[role='main'] .Bu:not(:first-child) {
            display: none !important;
        }
    </style>
    <style type="text/css">
        .jqstooltip {
            width: auto !important;
            height: auto !important;
            position: absolute;
            left: 0px;
            top: 0px;
            visibility: hidden;
            background: #000000;
            color: white;
            font-size: 11px;
            text-align: left;
            white-space: nowrap;
            padding: 5px;
            z-index: 10000;
        }

        .jqsfield {
            color: white;
            font: 10px arial, san serif;
            text-align: left;
        }

        .sidebar-nav li .active ul {
            display: block;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">

        <asp:HiddenField ID="hfpage" Value="1" runat="server" />

        <div id="page-container">
            <div id="main-container">
                <header class="navbar navbar-default">
                    <div class="nav navbar-nav-custom navbar-nav-custom-right">

                        <div class="header-top-left">
                            <asp:Label ID="lblUserName" runat="server">
                            </asp:Label>
                        </div>
                    </div>
                </header>
                <div style="min-height: 864px;" id="page-content">
                    <div class="row">

                        <div class="col-md-12" >
                            <div class="block" style="background-color: antiquewhite">
                                <div class="block-title">
                                    <h2>Student Registration</h2>
                                    <span style="float: right;">
                                        <asp:HiddenField ID="HfId" runat="server" />
                                        <asp:Label ID="lblmsg" runat="server" CssClass="label-display"></asp:Label>
                                    </span>
                                </div>
                                <div class="form-horizontal form-bordered">
                                    <div class="form-group" style="border-bottom: none;">
                                        <div class="col-md-12">


                                            <label class="control-label col-md-2">
                                                Full Name
                                            </label>
                                            <div class="col-md-3">
                                                <asp:TextBox ID="txtStudentName" placeholder="Enter Full Name"
                                                    CssClass="form-control" runat="server"></asp:TextBox>
                                                <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredDepartment" runat="server"
                                                    ControlToValidate="txtStudentName" ForeColor="Red" ValidationGroup="First">Please enter the full name</asp:RequiredFieldValidator>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="control-label col-md-2">
                                                Address
                                            </label>
                                            <div class="col-md-3">
                                                <asp:TextBox ID="txtAddress" placeholder="Enter Address"
                                                    CssClass="form-control" runat="server" TextMode="MultiLine"></asp:TextBox>
                                                <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator1" runat="server"
                                                    ControlToValidate="txtAddress" ForeColor="Red" ValidationGroup="First">Please enter the address</asp:RequiredFieldValidator>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="control-label col-md-2">
                                                Mobile Number
                                            </label>
                                            <div class="col-md-3">
                                                <asp:TextBox ID="txtMobileNumber" placeholder="Enter Mobile Number" MaxLength="10"
                                                    CssClass="form-control" runat="server"></asp:TextBox>
                                                <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator2" runat="server" ControlToValidate="txtMobileNumber" ForeColor="Red" ValidationGroup="First">Please enter the mobile number</asp:RequiredFieldValidator>
                                                <asp:RegularExpressionValidator ID="rvDigits" runat="server" ControlToValidate="txtMobileNumber" ErrorMessage="Enter numbers only till 10 digit" ValidationGroup="First" ForeColor="Red" ValidationExpression="[0-9]{10}" />

                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <label class="control-label col-md-2">
                                                Email Id
                                            </label>
                                            <div class="col-md-3">
                                                <asp:TextBox ID="txtEmail" placeholder="Enter Email Id" 
                                                    CssClass="form-control" runat="server"></asp:TextBox>
                                                <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator4" runat="server" ControlToValidate="txtEmail" ForeColor="Red" ValidationGroup="First">Please enter the emailid</asp:RequiredFieldValidator>
                                                 <asp:RegularExpressionValidator ID="RegularExpressionValidator1" runat="server" ControlToValidate="txtEmail" ErrorMessage="Enter valid email id" ValidationGroup="First" ForeColor="Red" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" />
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="control-label col-md-2">
                                            </label>
                                            <div class="col-md-3">
                                                <asp:Button Text="Register" ID="BtnSave" CssClass="btn btn-sm btn-primary" runat="server" OnClick="BtnSave_Click" ValidationGroup="First" BackColor="#ff9966"/>
                                                &nbsp;&nbsp;
                                                 <asp:Button ID="BtnClear" Text="Clear" runat="server" CssClass="btn btn-sm btn-danger"
                                                     CausesValidation="false" OnClick="BtnClear_Click" ValidationGroup="First"/>
                                                 <div style="clear: both; height: 15px;">
                                    </div>
                                                <asp:Button Text="Already have account! Go to login" ID="btnGotoLogin" CssClass="btn btn-sm btn-primary" runat="server" OnClick="btnGotoLogin_Click" BackColor="#ff9966"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div style="clear: both; height: 15px;">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12" runat="server" id="DivAccountActivation" visible="false">
                                <div class="block">
                                    <div class="block-title">
                                        <h2>Acount Activation</h2>
                                        <span style="float: right;">
                                            <asp:HiddenField ID="HiddenField1" runat="server" />
                                            <asp:Label ID="Label1" runat="server" CssClass="label-display"></asp:Label>
                                        </span>
                                    </div>
                                    <div class="form-horizontal form-bordered">
                                        <div class="form-group" style="border-bottom: none;">
                                            <div class="col-md-12">


                                                <label class="control-label col-md-2">
                                                    OTP
                                                </label>
                                                <div class="col-md-3">
                                                    <asp:TextBox ID="txtOTP" placeholder="Enter OTP"
                                                        CssClass="form-control" runat="server"></asp:TextBox>
                                                    <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator3" runat="server"
                                                        ControlToValidate="txtOTP" ForeColor="Red" ValidationGroup="Second">Please enter OTP</asp:RequiredFieldValidator>
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <label class="control-label col-md-2">
                                                </label>
                                                <div class="col-md-3">
                                                    <asp:Button Text="Activate" ID="btnActivate" CssClass="btn btn-sm btn-primary" runat="server" OnClick="btnActivate_Click" ValidationGroup="Second"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>





                        <%--<asp:ContentPlaceHolder ID="ContentPlaceHolder2" runat="server">
                                    </asp:ContentPlaceHolder>--%>
                    </div>
                </div>
            </div>
            </div>
        <a href="#" id="to-top"><i class="fa fa-chevron-up"></i></a>
        <!--[if IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
        <script src="../js/jquery.js"></script>
        <script>        !window.jQuery && document.write(unescape('%3Cscript src="js/vendor/jquery-1.11.0.min.js"%3E%3C/script%3E'));</script>
        <script src="../js/bootstrap.js"></script>
        <script src="../js/plugins_1.js"></script>
        <script src="../js/app_1.js"></script>
        <script src="../js/js"></script>
        <script src="../js/main.js" type="text/javascript"></script>
        <script src="../js/gmaps.js"></script>
        <script src="../js/index.js"></script>
        <script>        $(function () { Index.init(); });</script>
    </form>
</body>
</html>
