﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class Student_NoticeBoard : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        GetRecord();
    }


    void GetRecord()
    {
        SqlDataAdapter da = new SqlDataAdapter("Select * from NoticeBoard order by Id desc", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        gvDetails.DataSource = dt;
        gvDetails.DataBind();
    }


    protected void gvDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {
            int rowIndex = Convert.ToInt32(e.CommandArgument);
            //Fetch value of Name.
            string file = GetFileName(rowIndex);

            string filePath = "~/UploadFiles/Notice/" + file;
            Response.ContentType = "application/octet-stream";
            Response.AddHeader("Content-Disposition", "attachment;filename=\"" + filePath + "\"");
            Response.TransmitFile(Server.MapPath(filePath));
            Response.End();
        }
    }

    string GetFileName(int id)
    {
        SqlDataAdapter da = new SqlDataAdapter("Select FileName from NoticeBoard where Id=" + id + "", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt.Rows[0][0].ToString();
    }

    protected void gvDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvDetails.PageIndex = e.NewPageIndex;
        GetRecord();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            SqlDataAdapter da = new SqlDataAdapter("Select * from NoticeBoard where CreatedDate between '"+Convert.ToDateTime(txtFromDate.Text).ToString("MM/dd/yyyy")+ "' and '" + Convert.ToDateTime(txtToDate.Text).ToString("MM/dd/yyyy") + "' order by Id desc", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvDetails.DataSource = dt;
            gvDetails.DataBind();
        }
        catch (Exception ex)
        {

            lblmsg.ForeColor = Color.Red;
            lblmsg.Text = ex.Message;
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        GetRecord();
        txtFromDate.Text = "";
        txtToDate.Text = "";
    }
}