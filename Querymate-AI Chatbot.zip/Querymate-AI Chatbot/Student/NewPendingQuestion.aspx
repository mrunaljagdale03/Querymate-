﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Common/MasterPage.master" AutoEventWireup="true" CodeFile="NewPendingQuestion.aspx.cs" Inherits="Student_NewPendingQuestion" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" Runat="Server">
        <div class="col-md-12" style="height: 100px">
            <div class="block">
                <div class="block-title">
                    <h2>Invalid Question Answer</h2>
                    <span style="float: right;">
                        <asp:HiddenField ID="HfId" runat="server" />
                        <asp:Label ID="lblmsg" runat="server" CssClass="label-display"></asp:Label>
                    </span>
                </div>
                <div class="form-horizontal form-bordered">
                    <div class="form-group" style="border-bottom: none;">

                        <div style="clear: both; height: 15px;">
                        </div>

                        <div class="col-md-12">
                            <div class="col-md-8">
                                <asp:GridView ID="gvDetails" runat="server" AutoGenerateColumns="false" AllowPaging="True"
                                    CssClass="table table-vcenter table-condensed table-bordered dataTable grid-data"
                                    PageSize="10"
                                    CellPadding="9" OnPageIndexChanging="gvDetails_PageIndexChanging" >
                                    <PagerStyle CssClass="pagination pagination-sm remove-margin" />
                                    <Columns>

                                        <asp:TemplateField HeaderText="Sr. No." ItemStyle-HorizontalAlign="Center">
                                            <ItemTemplate>
                                                <%#Container.DataItemIndex+1 %>
                                            </ItemTemplate>
                                        </asp:TemplateField>

                                        <asp:TemplateField HeaderText="Question" ItemStyle-CssClass="gridText-left">
                                            <ItemTemplate>
                                                <asp:Label CssClass="me" ID="Hint1" runat="server" Text='<%#Bind("Hint1")%>'></asp:Label>
                                                <asp:HiddenField ID="HfId" runat="server" Value='<%#Bind("Id") %>' />
                                            </ItemTemplate>
                                        </asp:TemplateField>


                                               <asp:TemplateField HeaderText="Answer" ItemStyle-CssClass="gridText-left">
                                            <ItemTemplate>
                                                <asp:Label CssClass="me" ID="Answer" runat="server" Text='<%#Bind("Answer")%>'></asp:Label>
                                            </ItemTemplate>
                                        </asp:TemplateField>

                                         <asp:TemplateField HeaderText="Status" ItemStyle-CssClass="gridText-center">
                                            <ItemTemplate>
                                                <asp:Label CssClass="me" ID="status" runat="server" Text='<% #(Convert.ToBoolean(Eval("AnswerGiven"))==true?"Answered":"Pending") %>'></asp:Label>
                                            </ItemTemplate>
                                        </asp:TemplateField>
                                    </Columns>
                                </asp:GridView>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</asp:Content>

