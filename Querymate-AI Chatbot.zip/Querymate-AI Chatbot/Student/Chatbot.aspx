﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Common/MasterPage.master" AutoEventWireup="true" CodeFile="Chatbot.aspx.cs" Inherits="Student_Chatbot" Async="true" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="asp" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="Server">
    
            <div class="col-md-12" style="height: 100px">
                <div class="block">
                    <div class="block-title">
                        <h2>Chatbot</h2>
                        <span style="float: right;">
                            <asp:HiddenField ID="HfId" runat="server" />
                            <asp:Label ID="lblmsg" runat="server" CssClass="label-display"></asp:Label>
                        </span>
                    </div>
                    <div class="form-horizontal form-bordered">
                        <div class="form-group" style="border-bottom: none;">
                            <div class="col-md-12">
                                <label class="control-label col-md-2">
                                    Enter Your Query
                                </label>
                                <div class="col-md-3">
                                    <asp:TextBox ID="txtQuery" placeholder="Enter Your Query"
                                        CssClass="form-control" runat="server"></asp:TextBox>

                                    <asp:AutoCompleteExtender ServiceMethod="SearchQuestions"
                                        MinimumPrefixLength="4"
                                        CompletionInterval="100" EnableCaching="false" CompletionSetCount="10"
                                        TargetControlID="txtQuery"
                                        ID="AutoCompleteExtender1" runat="server" FirstRowSelected="false">
                                    </asp:AutoCompleteExtender>

                                    <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator1" runat="server"
                                        ControlToValidate="txtQuery" ForeColor="Red">Please Enter Your Query</asp:RequiredFieldValidator>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <label class="control-label col-md-2">
                                </label>
                                <div class="col-md-3">
                                    <asp:Button Text="Submit" ID="btnSubmit" CssClass="btn btn-sm btn-primary" runat="server" OnClick="btnSubmit_Click" />
                                </div>
                            </div>
                            <div style="clear: both; height: 15px;">
                            </div>
                            <div style="clear: both; height: 15px;">
                            </div>

                            <div class="col-md-12">
                                <label class="control-label col-md-2">
                                    Your Answer
                                </label>
                                <div class="col-md-3">
                                    <asp:TextBox ID="txtAnswer" TextMode="MultiLine"
                                        CssClass="form-control" runat="server"></asp:TextBox>
                                </div>
                            </div>

                            <div class="col-md-12">

                                <label class="control-label col-md-2">
                                </label>
                                <div class="col-md-3">
                                    <asp:Button ID="btnTalk" Text="Talk" runat="server" CssClass="btn btn-sm btn-danger"
                                        CausesValidation="false" OnClick="btnTalk_Click" />
                                    &nbsp;&nbsp;
                                    <asp:LinkButton ID="lnkVisitLink" runat="server" Visible="False" OnClick="lnkVisitLink_Click1">Visit Link</asp:LinkButton>

                                </div>
                            </div>
                            <div style="clear: both; height: 15px;">
                            </div>
                            <div style="clear: both; height: 15px;">
                            </div>
                            <div class="col-md-12" runat="server" id="DivConfirm" visible="false">
                                <label class="control-label col-md-2" style="color: red">
                                    Didn't get the right answer ?
                                </label>
                                <div class="col-md-3">
                                    <asp:RadioButton ID="radioYes" runat="server" Text="Yes" GroupName="c" AutoPostBack="true" OnCheckedChanged="radioYes_CheckedChanged" />
                                    &nbsp;&nbsp;
                                    <asp:RadioButton ID="radioNO" runat="server" Text="No" GroupName="c" AutoPostBack="true" OnCheckedChanged="radioNO_CheckedChanged" Checked="true" />
                                    <asp:Button ID="btnSubmitQuestion" Text="Submit Question" runat="server" CssClass="btn btn-sm btn-primary" CausesValidation="false" Enabled="false" OnClick="btnSubmitQuestion_Click" />



                                </div>
                            </div>

                            <div style="clear: both; height: 15px;">
                            </div>
                            <div style="clear: both; height: 15px;">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

</asp:Content>

