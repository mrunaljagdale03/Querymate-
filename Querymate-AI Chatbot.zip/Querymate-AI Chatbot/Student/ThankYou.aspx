﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ThankYou.aspx.cs" Inherits="Student_ThankYou" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Thank you</title>
    <style>
            .button {
  display: inline-block;
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 20px;
  width: 400px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
        </style>
</head>
<body>
    <form id="form1" runat="server">
        <div align="center" style="height:100%;vertical-align:middle;">
        <div style="width:500px;">
            <img src="../images/tick.png" width="350" height="300"/>
            <p style="font-size:xx-large;">Thank you for registration.</p><br /><p style="font-size:larger;"> Now you can login from here.</p><br />
              <div align="center" >
            <a class="button" style="vertical-align:middle" href="../StudentLogin.aspx"><span>Login</span></a>
        </div>
        </div>
</div>

    </form>
</body>
</html>
