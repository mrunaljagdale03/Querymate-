﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Common/MasterPage.master" AutoEventWireup="true" CodeFile="NoticeBoard.aspx.cs" Inherits="Student_NoticeBoard" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="asp" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" runat="Server">
    <div class="col-md-12" style="height: 100px">
        <div class="block">
            <div class="block-title">
                <h2>View Notice Board</h2>
                <span style="float: right;">
                    <asp:HiddenField ID="HfId" runat="server" />
                    <asp:Label ID="lblmsg" runat="server" CssClass="label-display"></asp:Label>
                </span>
            </div>

            <div class="form-horizontal form-bordered">
                <div class="form-group" style="border-bottom: none;">

                    <div class="col-md-12">
                        <label class="control-label col-md-2">
                            Search
                        </label>
                        <div class="col-md-3">
                            <asp:TextBox ID="txtFromDate" placeholder="Select From Date"
                                CssClass="form-control" runat="server"></asp:TextBox>

                            <asp:CalendarExtender ID="CalendarExtender1" runat="server" TargetControlID="txtFromDate" Format="dd/MM/yyyy"></asp:CalendarExtender>

                            <asp:TextBox ID="txtToDate" placeholder="Select To Date"
                                CssClass="form-control" runat="server"></asp:TextBox>
                            <asp:CalendarExtender ID="CalendarExtender2" runat="server" TargetControlID="txtToDate" Format="dd/MM/yyyy"></asp:CalendarExtender>
                            <asp:Button Text="Search" ID="btnSearch" CssClass="btn btn-sm btn-primary" runat="server" OnClick="btnSearch_Click" />
                            &nbsp;&nbsp;
                            <asp:Button ID="btnClear" Text="Clear" runat="server" CssClass="btn btn-sm btn-danger"
                                             CausesValidation="false" OnClick="btnClear_Click"  />
                        </div>
                    </div>
                    <div style="clear: both; height: 15px;">
                    </div>

                    <asp:GridView ID="gvDetails" runat="server" AutoGenerateColumns="false" AllowPaging="True"
                        CssClass="table table-vcenter table-condensed table-bordered dataTable grid-data"
                        PageSize="10" OnRowCommand="gvDetails_RowCommand"
                        CellPadding="9" OnPageIndexChanging="gvDetails_PageIndexChanging">
                        <PagerStyle CssClass="pagination pagination-sm remove-margin" />
                        <Columns>

                            <asp:TemplateField HeaderText="Sr. No." ItemStyle-HorizontalAlign="Center">
                                <ItemTemplate>
                                    <%#Container.DataItemIndex+1 %>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <asp:TemplateField HeaderText="Notice Title" ItemStyle-CssClass="gridText-left">
                                <ItemTemplate>
                                    <asp:Label CssClass="me" ID="NoticeTitle" runat="server" Text='<%#Bind("NoticeTitle")%>'></asp:Label>
                                    <asp:HiddenField ID="HfId" runat="server" Value='<%#Bind("Id") %>' />
                                </ItemTemplate>
                            </asp:TemplateField>

                            <asp:TemplateField HeaderText="Notice Description" ItemStyle-CssClass="gridText-left">
                                <ItemTemplate>
                                    <asp:Label CssClass="me" ID="NoticeDescription" runat="server" Text='<%#Bind("NoticeDescription")%>'></asp:Label>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <asp:TemplateField HeaderText="Notice Date" ItemStyle-CssClass="gridText-center">
                                <ItemTemplate>
                                    <asp:Label CssClass="me" ID="CreatedDate" runat="server" Text='<%#Convert.ToDateTime(Eval("CreatedDate")).ToString("dd-MMM-yyyy")%>'></asp:Label>
                                </ItemTemplate>
                            </asp:TemplateField>

                            <asp:TemplateField HeaderText="Download" ItemStyle-CssClass="gridText-center">
                                <ItemTemplate>
                                    <asp:HiddenField ID="HfFileName" runat="server" Value='<%#Bind("FileName") %>' />
                                    <asp:LinkButton CssClass="me" ID="btnDownload" runat="server" CausesValidation="false" Text='Download' CommandName="Select" CommandArgument='<%#Bind("Id")%>'></asp:LinkButton>
                                </ItemTemplate>
                            </asp:TemplateField>


                        </Columns>
                    </asp:GridView>
                </div>
            </div>
        </div>
    </div>
</asp:Content>

