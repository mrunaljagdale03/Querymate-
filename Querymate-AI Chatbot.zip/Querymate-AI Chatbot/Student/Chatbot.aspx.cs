﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Speech.Synthesis;

public partial class Student_Chatbot : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);
    SqlDataAdapter da = null;
    // creating the object of SpeechSynthesizer class  
    SpeechSynthesizer sp = new SpeechSynthesizer();


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["LoginId"] == null)
        {
            Response.Redirect("~/SessionExpired.aspx");
        }
    }

    protected void btnTalk_Click(object sender, EventArgs e)
    {

        //setting volume   
        sp.Volume = 100;
        sp.Rate = 0;
        sp.SelectVoiceByHints(VoiceGender.Female);
        //ing text box text to SpeakAsync method   
        sp.Speak(txtAnswer.Text);
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        txtAnswer.Text = "";
        SearchingAlgorithm();
    }

    void SearchingAlgorithm()
    {
        List<string> wordsToRemove = "is the on of it this there was by".Split(' ').ToList();
        string data = txtQuery.Text.Trim();
        string finalData = string.Join(" ", data.ToLower().Split(' ').Except(wordsToRemove));
        string[] words = finalData.Split(' ');
        SearchResult(words);
    }

    void SearchResult(string[] words)
    {
        var extractResult = ExtractResult();
        var results = new List<Result>();
        foreach (var item in extractResult)
        {
            int totalMatched = 0;

            Result result = new Result();
            foreach (var word in words)
            {
                int match = 0;
                if (item.Hint1.ToLower().ToLower().Contains(word.ToLower()))
                {
                    match += 1;
                }
                if (item.Hint2.ToLower().Contains(word.ToLower()))
                {
                    match += 1;
                }
                if (item.Hint3.ToLower().Contains(word.ToLower()))
                {
                    match += 1;
                }
                if (match > 0)
                {
                    totalMatched += 1;
                }
            }
            if (totalMatched > 0)
            {
                result.Count = totalMatched;
                result.Answer = item.Answer;
                result.FileName = item.VisitLink;
                results.Add(result);
            }
        }

        if (results.Count > 0)
        {
            lblmsg.Text = "";

            var data = results.OrderByDescending(x => x.Count).First();

            if (data.Count >= 1)
            {
                txtAnswer.Text = data.Answer;
                if (!string.IsNullOrEmpty(data.FileName))
                {
                    lnkVisitLink.Visible = true;
                    HfId.Value = data.FileName;
                }
                DivConfirm.Visible = true;
            }

            else
            {
                lblmsg.ForeColor = Color.Red;
                lblmsg.Text = "Sorry I don't get you.";
                DivConfirm.Visible = true;
            }
        }
        else
        {
            lblmsg.ForeColor = Color.Red;
            lblmsg.Text = "Sorry I don't get you.";
            DivConfirm.Visible = true;
        }
    }


    private void AddInvalidQuestion()
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Question(Hint1,CreatedBy,AnswerGiven) values('" + txtQuery.Text + "'," + Convert.ToInt32(Session["LoginId"]) + ",0)", con);
            int result = cmd.ExecuteNonQuery();
            if (result >= 0)
            {
                lblmsg.ForeColor = Color.Green;
                lblmsg.Text = "Question Submitted Successfully";
                Clear();
                con.Close();
                cmd.Dispose();
            }
            else
            {
                lblmsg.ForeColor = Color.Red;
                lblmsg.Text = "Record Failed To add question";
            }
        }
        catch (Exception ex)
        {

            lblmsg.ForeColor = Color.Red;
            lblmsg.Text = ex.Message;
        }

    }


    private void Clear()
    {
        txtQuery.Text = "";
        txtAnswer.Text = "";
        DivConfirm.Visible = false;
    }
    protected void lnkVisitLink_Click1(object sender, EventArgs e)
    {
        string filePath = "~/UploadFiles/" + HfId.Value;
        Response.ContentType = "application/octet-stream";
        Response.AddHeader("Content-Disposition", "attachment;filename=\"" + filePath + "\"");
        Response.TransmitFile(Server.MapPath(filePath));
        Response.End();
    }


    private List<QuestionAnswer> ExtractResult()
    {
        da = new SqlDataAdapter("Select * from Question order by Id desc", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        var questionAnswerList = ConvertDataTable<QuestionAnswer>(dt);
        return questionAnswerList;
    }

    private static List<T> ConvertDataTable<T>(DataTable dt)
    {
        List<T> data = new List<T>();
        foreach (DataRow row in dt.Rows)
        {
            T item = GetItem<T>(row);
            data.Add(item);
        }
        return data;
    }
    private static T GetItem<T>(DataRow dr)
    {
        Type temp = typeof(T);
        T obj = Activator.CreateInstance<T>();

        foreach (DataColumn column in dr.Table.Columns)
        {
            foreach (PropertyInfo pro in temp.GetProperties())
            {
                if (pro.Name == column.ColumnName)
                    pro.SetValue(obj, dr[column.ColumnName], null);
                else
                    continue;
            }
        }
        return obj;
    }

    protected void btnSubmitQuestion_Click(object sender, EventArgs e)
    {
        AddInvalidQuestion();
    }

    protected void radioYes_CheckedChanged(object sender, EventArgs e)
    {
        if (radioYes.Checked)
        {
            btnSubmitQuestion.Enabled = true;
        }
    }

    protected void radioNO_CheckedChanged(object sender, EventArgs e)
    {
        if (radioNO.Checked)
        {
            btnSubmitQuestion.Enabled = false;
        }
    }

    [System.Web.Script.Services.ScriptMethod()]
    [System.Web.Services.WebMethod]
    public static List<string> SearchQuestions(string prefixText)
    {
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager
                    .ConnectionStrings["constr"].ConnectionString;
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select Hint1 from Question where " +
                "Hint1 like '%'+ @SearchText + '%'";
                cmd.Parameters.AddWithValue("@SearchText", prefixText);
                cmd.Connection = conn;
                conn.Open();
                List<string> list1 = new List<string>();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        list1.Add(sdr["Hint1"].ToString());
                    }
                }
                var list2 = GetList2(prefixText);
                var list3 = GetList3(prefixText);
                list1.AddRange(list2);
                list1.AddRange(list3);
                conn.Close();
                return list1;
            }
        }
    }

    private static List<string> GetList2(string prefixText)
    {
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager
                    .ConnectionStrings["constr"].ConnectionString;
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select Hint2 from Question where " +
                "Hint2 like '%'+ @SearchText + '%'";
                cmd.Parameters.AddWithValue("@SearchText", prefixText);
                cmd.Connection = conn;
                conn.Open();
                List<string> list2 = new List<string>();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        list2.Add(sdr["Hint2"].ToString());
                    }
                }

                conn.Close();
                return list2;
            }
        }
    }

    private static List<string> GetList3(string prefixText)
    {
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager
                    .ConnectionStrings["constr"].ConnectionString;
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select Hint3 from Question where " +
                "Hint3 like '%'+ @SearchText + '%'";
                cmd.Parameters.AddWithValue("@SearchText", prefixText);
                cmd.Connection = conn;
                conn.Open();
                List<string> list3 = new List<string>();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        list3.Add(sdr["Hint3"].ToString());
                    }
                }

                conn.Close();
                return list3;
            }
        }
    }


}