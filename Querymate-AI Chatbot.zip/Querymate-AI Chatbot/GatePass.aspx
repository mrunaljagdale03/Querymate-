﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="GatePass.aspx.cs" Inherits="GatePass" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Gate Pass</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1.0" />
    <link href="../css/googleapis.css" rel="stylesheet" type="text/css" />
    <link href="../css/Style.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="../css/bootstrap.css" />
    <link rel="stylesheet" href="../css/plugins_1.css" />
    <link rel="stylesheet" href="../css/main_1.css" />
    <link rel="stylesheet" href="../css/themes.css" />
    <script src="js/jquery.js"></script>
    <script src="js/modernizr-2.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <script type="text/javascript" src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>

    <style type="text/css">
        #fi #fic {
            margin-right: 100px !important;
        }

        #fi #rh {
            margin-left: -115px !important;
            width: 95px !important;
        }

        #fi .rh {
            display: none !important;
        }

        body:not(.xE) div[role='main'] .Bu:not(:first-child) {
            display: none !important;
        }
    </style>
    <style type="text/css">
        .jqstooltip {
            width: auto !important;
            height: auto !important;
            position: absolute;
            left: 0px;
            top: 0px;
            visibility: hidden;
            background: #000000;
            color: white;
            font-size: 11px;
            text-align: left;
            white-space: nowrap;
            padding: 5px;
            z-index: 10000;
        }

        .jqsfield {
            color: white;
            font: 10px arial, san serif;
            text-align: left;
        }

        .sidebar-nav li .active ul {
            display: block;
        }
    </style>



</head>
<body>
    <form id="form1" runat="server">

        <asp:HiddenField ID="hfpage" Value="1" runat="server" />

        <div id="divpass">

            <div id="page-container">
                <div id="main-container">
                    <header class="navbar navbar-default">
                        <div class="nav navbar-nav-custom navbar-nav-custom-right">

                            <div class="header-top-left">
                                <asp:Label ID="lblUserName" runat="server">
                                </asp:Label>
                            </div>
                        </div>
                    </header>
                    <div style="min-height: 864px;" id="page-content">
                        <div class="row">

                            <div class="col-md-12">
                                <div class="block">
                                    <div class="block-title">
                                        <h2>Gate Pass</h2>
                                        <span style="float: right;">
                                            <asp:HiddenField ID="HfId" runat="server" />
                                            <asp:Label ID="lblmsg" runat="server" CssClass="label-display"></asp:Label>
                                        </span>
                                    </div>
                                    <div class="form-horizontal form-bordered">
                                        <div class="form-group" style="border-bottom: none;">
                                            <div class="col-md-12">


                                                <label class="control-label col-md-2">
                                                    Visitor Name
                                                </label>
                                                <div class="col-md-3">
                                                    <asp:TextBox ID="txtVisitorName" placeholder="Enter Full Name"
                                                        CssClass="form-control" runat="server"></asp:TextBox>
                                                     <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredDepartment" runat="server"
                                                        ControlToValidate="txtVisitorName" ForeColor="Red">Please enter the full name</asp:RequiredFieldValidator>
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <label class="control-label col-md-2">
                                                    Mobile Number
                                                </label>
                                                <div class="col-md-3">
                                                    <asp:TextBox ID="txtMobileNumber" placeholder="Enter Mobile Number" MaxLength="10"
                                                        CssClass="form-control" runat="server"></asp:TextBox>
                                                      <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator2" runat="server" ControlToValidate="txtMobileNumber" ForeColor="Red">Please enter the mobile number</asp:RequiredFieldValidator>
                                                    <asp:RegularExpressionValidator ID="rvDigits" runat="server" ControlToValidate="txtMobileNumber" ErrorMessage="Enter numbers only till 10 digit" ForeColor="Red" ValidationExpression="[0-9]{10}" />
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <label class="control-label col-md-2">
                                                    Contact Person Name
                                                </label>
                                                <div class="col-md-3">
                                                    <asp:TextBox ID="txtContactPersonName" placeholder="Enter Contact Person Name"
                                                        CssClass="form-control" runat="server"></asp:TextBox>
                                                    <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator4" runat="server" ControlToValidate="txtContactPersonName" ForeColor="Red">Please enter Contact Person Name</asp:RequiredFieldValidator>
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <label class="control-label col-md-2">
                                                    Purpose
                                                </label>
                                                <div class="col-md-3">
                                                    <asp:TextBox ID="txtPurpose" placeholder="Enter Contact Person Name"
                                                        CssClass="form-control" runat="server"></asp:TextBox>
                                                    <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtPurpose" ForeColor="Red">Please enter Purpose</asp:RequiredFieldValidator>
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <label class="control-label col-md-2">
                                                </label>
                                                <div class="col-md-3">
                                                    <asp:Button CssClass="btn btn-sm btn-primary" Id="BtnSave" runat="server" OnClick="BtnSave_Click" Text="Generate Pass"></asp:Button>
                                                    &nbsp;&nbsp;
                                                     <asp:Button CssClass="btn btn-sm btn-primary" Id="btnAdd" runat="server" OnClick="btnAdd_Click" Text="Save"></asp:Button>
                                                       &nbsp;&nbsp;
                                                    <asp:Button ID="btnClear" Text="Clear" runat="server" CssClass="btn btn-sm btn-danger" OnClick="btnClear_Click" CausesValidation="false"  />
                        <div style="clear: both; height: 15px;">
                        </div>

                                                </div>
                                            </div>


                                        </div>
                                        <div style="clear: both; height: 15px;">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <a href="#" id="to-top"><i class="fa fa-chevron-up"></i></a>
        <!--[if IE 8]><script src="js/excanvas.min.js"></script><![endif]-->
        <script src="../js/jquery.js"></script>
        <script>        !window.jQuery && document.write(unescape('%3Cscript src="js/vendor/jquery-1.11.0.min.js"%3E%3C/script%3E'));</script>
        <script src="../js/bootstrap.js"></script>
        <script src="../js/plugins_1.js"></script>
        <script src="../js/app_1.js"></script>
        <script src="../js/main.js" type="text/javascript"></script>
        <script src="../js/gmaps.js"></script>
        <script src="../js/index.js"></script>
        <script>        $(function () { Index.init(); });</script>
    </form>
</body>
</html>
