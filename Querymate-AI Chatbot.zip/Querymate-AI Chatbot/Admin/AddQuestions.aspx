﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Common/MasterPage.master" AutoEventWireup="true" CodeFile="AddQuestions.aspx.cs" Inherits="Admin_AddQuestions" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" Runat="Server">
            <div class="col-md-12" style="height: 100px">
                <div class="block">
                    <div class="block-title">
                        <h2>Add Question</h2>
                        <span style="float: right;">
                            <asp:HiddenField ID="HfId" runat="server" />
                            <asp:Label ID="lblmsg" runat="server" CssClass="label-display"></asp:Label>
                        </span>
                    </div>
                    <div class="form-horizontal form-bordered">
                        <div class="form-group" style="border-bottom: none;">
                            <div class="col-md-12">
                                <label class="control-label col-md-2">
                                    Question Hints
                                </label>
                                <div class="col-md-3">
                                    <asp:TextBox ID="txtHint1" placeholder="Enter Hint 1" 
                                        CssClass="form-control" runat="server"></asp:TextBox>
                                    <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator1" runat="server"
                                        ControlToValidate="txtHint1" ForeColor="Red">Please Enter Hint</asp:RequiredFieldValidator>
                                </div>

                                <div class="col-md-3">
                                    <asp:TextBox ID="txtHint2" placeholder="Enter Hint 2" 
                                        CssClass="form-control" runat="server"></asp:TextBox>
                                    <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator2" runat="server"
                                        ControlToValidate="txtHint2" ForeColor="Red">Please Enter Hint</asp:RequiredFieldValidator>
                                </div>

                                <div class="col-md-3">
                                    <asp:TextBox ID="txtHint3" placeholder="Enter Hint 3" 
                                        CssClass="form-control" runat="server"></asp:TextBox>
                                    <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator3" runat="server"
                                        ControlToValidate="txtHint3" ForeColor="Red">Please Enter Hint</asp:RequiredFieldValidator>
                                </div>
                            </div>
                            
                            

                               <div class="col-md-12">
                                <label class="control-label col-md-2">
                                    Enter Answer
                                </label>
                                <div class="col-md-3">
                                    <asp:TextBox ID="txtAnswer" TextMode="MultiLine" 
                                        CssClass="form-control" runat="server"></asp:TextBox>
                                       <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator4" runat="server"
                                        ControlToValidate="txtAnswer" ForeColor="Red">Please Enter Answer</asp:RequiredFieldValidator>
                                </div>
                            </div>


                               <div class="col-md-12">
                                <label class="control-label col-md-2">
                                    Upload
                                </label>
                                <div class="col-md-3">
                                    <asp:FileUpload ID="FileUpload1" runat="server" />
                                </div>
                            </div>

                              <div class="col-md-12">

                                  <label class="control-label col-md-2">
                                      </label>
                                  <div class="col-md-3">   
                                      
                                        
                            <asp:Button Text="Submit" ID="btnSubmit" CssClass="btn btn-sm btn-primary" runat="server" OnClick="btnSubmit_Click"  />
                                         <asp:Button ID="btnClear" Text="Clear" runat="server" CssClass="btn btn-sm btn-danger"
                                             CausesValidation="false" OnClick="btnClear_Click"  />

                                     
                               
                            </div>
                            </div>
                          

                            <div style="clear: both; height: 15px;">
                            </div>
                            <div style="clear: both; height: 15px;">
                            </div>

                             <div class="col-md-12">
                                <div class="col-md-8">
                                    <asp:GridView ID="gvDetails" runat="server" AutoGenerateColumns="false" AllowPaging="True"
                                        CssClass="table table-vcenter table-condensed table-bordered dataTable grid-data"
                                        PageSize="10"
                                        CellPadding="9" OnRowCommand="gvDetails_RowCommand">
                                        <PagerStyle CssClass="pagination pagination-sm remove-margin" />
                                        <Columns>

                                            <asp:TemplateField HeaderText="Sr. No." ItemStyle-HorizontalAlign="Center">
                                                <ItemTemplate>
                                                    <%#Container.DataItemIndex+1 %>
                                                </ItemTemplate>
                                            </asp:TemplateField>

                                            <asp:TemplateField HeaderText="Hint1" ItemStyle-CssClass="gridText-left">
                                                <ItemTemplate>
                                                    <asp:Label CssClass="me" ID="Hint1" runat="server" Text='<%#Bind("Hint1")%>'></asp:Label>
                                                    <asp:HiddenField ID="HfId" runat="server" Value='<%#Bind("Id") %>' />
                                                </ItemTemplate>
                                            </asp:TemplateField>

                                            <asp:TemplateField HeaderText="Hint2" ItemStyle-CssClass="gridText-left">
                                                <ItemTemplate>
                                                    <asp:Label CssClass="me" ID="Hint2" runat="server" Text='<%#Bind("Hint2")%>'></asp:Label>
                                                </ItemTemplate>
                                            </asp:TemplateField>

                                               <asp:TemplateField HeaderText="Hint3" ItemStyle-CssClass="gridText-left">
                                                <ItemTemplate>
                                                    <asp:Label CssClass="me" ID="Hint3" runat="server" Text='<%#Bind("Hint3")%>'></asp:Label>
                                                </ItemTemplate>
                                            </asp:TemplateField>

                                               <asp:TemplateField HeaderText="Answer" ItemStyle-CssClass="gridText-left">
                                                <ItemTemplate>
                                                    <asp:Label CssClass="me" ID="Answer" runat="server" Text='<%#Bind("Answer")%>'></asp:Label>
                                                </ItemTemplate>
                                            </asp:TemplateField>

                                            <asp:TemplateField HeaderText="Action">
                                                <ItemTemplate>
                                                    <asp:LinkButton ID="btnEdit" runat="server" AlternateText="Edit" CommandName="Updates"
                                                        CommandArgument='<%#Bind("Id")%>' CausesValidation="false" data-toggle="tooltip"
                                                        ToolTip="Edit" class="btn btn-xs btn-default">
                                        <i class="fa fa-pencil" style="line-height:inherit;"></i>
                                                    </asp:LinkButton>
                                                    <asp:LinkButton ID="btnDel" runat="server" AlternateText="Delete" CommandName="deletes"
                                                        CommandArgument='<%#Bind("Id")%>' OnClientClick="return confirm('Are you sure you want to delete this Record?');"
                                                        CausesValidation="false" data-toggle="tooltip" ToolTip="Delete" class="btn btn-xs btn-danger">
                                        <i class="fa fa-times" style="line-height:inherit;"></i>
                                                    </asp:LinkButton>
                                                </ItemTemplate>
                                            </asp:TemplateField>
                                        </Columns>
                                    </asp:GridView>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</asp:Content>

