﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddNotice : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        GetRecord();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string filename = null;
            if (FileUpload2.FileBytes.Length > 1)
            {
                filename = Path.GetFileNameWithoutExtension(FileUpload2.FileName) + "_" + Guid.NewGuid() + Path.GetExtension(FileUpload2.FileName);
                FileUpload2.PostedFile.SaveAs(Server.MapPath("~/UploadFiles/Notice/" + filename));
            }
            if (btnSubmit.Text == "Submit")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into NoticeBoard values('" + txtNoticeTitle.Text + "','" + txtDescription.Text + "','" + filename + "','" + DateTime.Now + "')", con);
                int result = cmd.ExecuteNonQuery();
                if (result >= 0)
                {
                    lblmsg.ForeColor = Color.Green;
                    lblmsg.Text = "Record Inserted Successfully";
                    Clear();
                    GetRecord();
                    con.Close();
                    cmd.Dispose();
                }
                else
                {
                    lblmsg.ForeColor = Color.Red;
                    lblmsg.Text = "Record Failed To Inserted";
                }
            }

            else if (btnSubmit.Text == "Update")
            {
                string updateFileName = string.Empty;
                if (!FileUpload2.HasFile)
                {
                    updateFileName = hfFile.Value;
                }
                else
                {
                    updateFileName = filename;
                }
                con.Open();
                SqlCommand cmd = new SqlCommand("update NoticeBoard set NoticeTitle='" + txtNoticeTitle.Text + "',NoticeDescription='" + txtDescription.Text + "',FileName='" + updateFileName + "' where Id=" + HfId.Value + "", con);
                int result = cmd.ExecuteNonQuery();
                if (result >= 0)
                {
                    lblmsg.ForeColor = Color.Green;
                    lblmsg.Text = "Record Updated Successfully";
                    Clear();
                    GetRecord();
                    con.Close();
                    cmd.Dispose();
                }
                else
                {
                    lblmsg.ForeColor = Color.Red;
                    lblmsg.Text = "Record Failed To Update";
                }
            }


        }
        catch (Exception ex)
        {
            lblmsg.ForeColor = Color.Red;
            lblmsg.Text = ex.Message;
        }
    }

 

    protected void gvDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Updates")
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from NoticeBoard where Id='" + e.CommandArgument.ToString() + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                HfId.Value = dt.Rows[0]["Id"].ToString();
                txtNoticeTitle.Text = dt.Rows[0]["NoticeTitle"].ToString();
                txtDescription.Text = dt.Rows[0]["NoticeDescription"].ToString();
                hfFile.Value = dt.Rows[0]["FileName"].ToString();
                btnSubmit.Text = "Update";
            }

            else if (e.CommandName == "deletes")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete from NoticeBoard where Id='" + e.CommandArgument.ToString() + "'", con);
                int result = cmd.ExecuteNonQuery();
                if (result >= 0)
                {
                    lblmsg.ForeColor = Color.Green;
                    lblmsg.Text = "Record Deleted Successfully";
                    Clear();
                    GetRecord();
                    con.Close();
                    cmd.Dispose();
                }
                else
                {
                    lblmsg.ForeColor = Color.Red;
                    lblmsg.Text = "Record Failed To Delete";
                }
            }

           else if (e.CommandName == "Select")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                //Fetch value of Name.
                string file = GetFileName(rowIndex);

                string filePath = "~/UploadFiles/Notice/" + file;
                Response.ContentType = "application/octet-stream";
                Response.AddHeader("Content-Disposition", "attachment;filename=\"" + filePath + "\"");
                Response.TransmitFile(Server.MapPath(filePath));
                Response.End();
            }
            }
        catch (Exception ex)
        {
            lblmsg.ForeColor = Color.Red;
            lblmsg.Text = ex.Message;
        }
    }

    private void Clear()
    {
        txtNoticeTitle.Text = "";
        txtDescription.Text = "";
        btnSubmit.Text = "Submit";
        FileUpload2.Dispose();

    }

    void GetRecord()
    {
        SqlDataAdapter da = new SqlDataAdapter("Select * from NoticeBoard order by Id desc", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        gvDetails.DataSource = dt;
        gvDetails.DataBind();
    }


    string GetFileName(int id)
    {
        SqlDataAdapter da = new SqlDataAdapter("Select FileName from NoticeBoard where Id=" + id + "", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt.Rows[0][0].ToString();
    }

    protected void gvDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvDetails.PageIndex = e.NewPageIndex;
        GetRecord();
    }
}