﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Web.UI.WebControls;

public partial class Admin_AddQuestions : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetRecord();
            GetQuestion(Convert.ToInt32(Request.QueryString["id"]));
        }
    }

    private void GetQuestion(int id)
    {
        if (id>0)
        {
            SqlDataAdapter da = new SqlDataAdapter("Select * from Question where Id="+id+" order by Id desc", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            txtHint1.Text = dt.Rows[0]["Hint1"].ToString();
            btnSubmit.Text = "Update";
            HfId.Value = id.ToString();
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string filename = null;
            if (FileUpload1.FileBytes.Length > 1)
            {
                filename = Path.GetFileNameWithoutExtension(FileUpload1.FileName) + "_" + Guid.NewGuid() + Path.GetExtension(FileUpload1.FileName);
                FileUpload1.PostedFile.SaveAs(Server.MapPath("~/UploadFiles/" + filename));
            }
            if (btnSubmit.Text == "Submit")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into Question values('" + txtHint1.Text + "','" + txtHint2.Text + "','" + txtHint3.Text + "','" + txtAnswer.Text + "','" + filename + "',null,1)", con);
                int result = cmd.ExecuteNonQuery();
                if (result >= 0)
                {
                    lblmsg.ForeColor = Color.Green;
                    lblmsg.Text = "Record Inserted Successfully";
                    Clear();
                    GetRecord();
                    con.Close();
                    cmd.Dispose();
                }
                else
                {
                    lblmsg.ForeColor = Color.Red;
                    lblmsg.Text = "Record Failed To Inserted";
                }
            }

            else if (btnSubmit.Text == "Update")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update Question set Hint1='" + txtHint1.Text+ "',Hint2='" + txtHint2.Text + "',Hint3='" + txtHint3.Text + "',Answer='" + txtAnswer.Text + "',VisitLink='" + filename + "',AnswerGiven=1 where Id=" + HfId.Value + "", con);
                int result = cmd.ExecuteNonQuery();
                if (result >= 0)
                {
                    lblmsg.ForeColor = Color.Green;
                    lblmsg.Text = "Record Updated Successfully";
                    Clear();
                    GetRecord();
                    con.Close();
                    cmd.Dispose();
                }
                else
                {
                    lblmsg.ForeColor = Color.Red;
                    lblmsg.Text = "Record Failed To Update";
                }
            }


        }
        catch (Exception ex)
        {
            lblmsg.ForeColor = Color.Red;
            lblmsg.Text = ex.Message;
        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Clear();
        lblmsg.Text = "";
        Response.Redirect("~/Admin/AddQuestions.aspx");
    }

    private void Clear()
    {
        txtHint1.Text = "";
        txtHint2.Text = "";
        txtHint3.Text = "";
        txtAnswer.Text = "";
        btnSubmit.Text = "Submit";
        FileUpload1.Dispose();
    }

    void GetRecord()
    {
        SqlDataAdapter da = new SqlDataAdapter("Select * from Question where AnswerGiven=1 order by Id desc", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        gvDetails.DataSource = dt;
        gvDetails.DataBind();
    }

    protected void gvDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Updates")
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from Question where Id='" + e.CommandArgument.ToString() + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                HfId.Value = dt.Rows[0]["Id"].ToString();
                txtHint1.Text = dt.Rows[0]["Hint1"].ToString();
                txtHint2.Text = dt.Rows[0]["Hint2"].ToString();
                txtHint3.Text = dt.Rows[0]["Hint3"].ToString();
                txtAnswer.Text = dt.Rows[0]["Answer"].ToString();
                btnSubmit.Text = "Update";
            }

            else if (e.CommandName == "deletes")
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete from Question where Id='" + e.CommandArgument.ToString() + "'", con);
                int result = cmd.ExecuteNonQuery();
                if (result >= 0)
                {
                    lblmsg.ForeColor = Color.Green;
                    lblmsg.Text = "Record Deleted Successfully";
                    Clear();
                    GetRecord();
                    con.Close();
                    cmd.Dispose();
                }
                else
                {
                    lblmsg.ForeColor = Color.Red;
                    lblmsg.Text = "Record Failed To Delete";
                }
            }
        }
        catch (Exception ex)
        {
            lblmsg.ForeColor = Color.Red;
            lblmsg.Text = ex.Message;
        }
    }
}