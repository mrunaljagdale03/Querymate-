﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Common/MasterPage.master" AutoEventWireup="true" CodeFile="AddNotice.aspx.cs" Inherits="Admin_AddNotice" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder2" Runat="Server">
       
            <div class="col-md-12" style="height: 100px">
                <div class="block">
                    <div class="block-title">
                        <h2>Add Notice</h2>
                        <span style="float: right;">
                            <asp:HiddenField ID="HfId" runat="server" />
                            <asp:Label ID="lblmsg" runat="server" CssClass="label-display"></asp:Label>
                        </span>
                    </div>
                    <div class="form-horizontal form-bordered">
                        <div class="form-group" style="border-bottom: none;">
                            <div class="col-md-12">
                                <label class="control-label col-md-2">
                                    Notice Title
                                </label>
                                <div class="col-md-3">
                                    <asp:TextBox ID="txtNoticeTitle" placeholder="Enter Notice Title" 
                                        CssClass="form-control" runat="server"></asp:TextBox>
                                    <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator1" runat="server"
                                        ControlToValidate="txtNoticeTitle" ForeColor="Red">Please Notice Title</asp:RequiredFieldValidator>
                                </div>
                            </div>
                            
                               <div class="col-md-12">
                                <label class="control-label col-md-2">
                                    Description
                                </label>
                                <div class="col-md-3">
                                    <asp:TextBox ID="txtDescription" placeholder="Enter Description" 
                                        CssClass="form-control" runat="server"></asp:TextBox>
                                    <asp:RequiredFieldValidator Display="Dynamic" ID="RequiredFieldValidator2" runat="server"
                                        ControlToValidate="txtDescription" ForeColor="Red">Please Description</asp:RequiredFieldValidator>
                                </div>
                            </div>

                            
                               <div class="col-md-12">
                                <label class="control-label col-md-2">
                                    Upload
                                </label>
                                <div class="col-md-3">
                                    <asp:FileUpload ID="FileUpload2" runat="server" />
                                       <asp:RequiredFieldValidator runat="server" Display="Dynamic" ErrorMessage="Please upload the file" ForeColor="Red" ControlToValidate="FileUpload2">
    </asp:RequiredFieldValidator>
                                </div>
                            </div>
                            

                             

                              <div class="col-md-12">

                                  <label class="control-label col-md-2">
                                      </label>
                                  <div class="col-md-3">   
                                      
                                        
                            <asp:Button Text="Submit" ID="btnSubmit" CssClass="btn btn-sm btn-primary" runat="server" OnClick="btnSubmit_Click"  />
                                         <asp:Button ID="btnClear" Text="Clear" runat="server" CssClass="btn btn-sm btn-danger"
                                             CausesValidation="false"  />

                                     
                               
                                      <asp:HiddenField ID="hfFile" runat="server" />

                                     
                               
                            </div>
                            </div>
                          

                            <div style="clear: both; height: 15px;">
                            </div>
                            <div style="clear: both; height: 15px;">
                            </div>

                                <div class="col-md-12">
                                <div class="col-md-8">
                                    <asp:GridView ID="gvDetails" runat="server" AutoGenerateColumns="false" AllowPaging="True" DataKeyNames="Id" 
                                        CssClass="table table-vcenter table-condensed table-bordered dataTable grid-data"
                                        PageSize="10"
                                        CellPadding="9" OnRowCommand="gvDetails_RowCommand" OnPageIndexChanging="gvDetails_PageIndexChanging">
                                        <PagerStyle CssClass="pagination pagination-sm remove-margin" />
                                        <Columns>

                                            <asp:TemplateField HeaderText="Sr. No." ItemStyle-HorizontalAlign="Center">
                                                <ItemTemplate>
                                                    <%#Container.DataItemIndex+1 %>
                                                </ItemTemplate>
                                            </asp:TemplateField>

                                            <asp:TemplateField HeaderText="Notice Title" ItemStyle-CssClass="gridText-left">
                                                <ItemTemplate>
                                                    <asp:Label CssClass="me" ID="NoticeTitle" runat="server" Text='<%#Bind("NoticeTitle")%>'></asp:Label>
                                                    <asp:HiddenField ID="HfId" runat="server" Value='<%#Bind("Id") %>' />
                                                </ItemTemplate>
                                            </asp:TemplateField>

                                            <asp:TemplateField HeaderText="Notice Description" ItemStyle-CssClass="gridText-left">
                                                <ItemTemplate>
                                                    <asp:Label CssClass="me" ID="NoticeDescription" runat="server" Text='<%#Bind("NoticeDescription")%>'></asp:Label>
                                                </ItemTemplate>
                                            </asp:TemplateField>

                                               <asp:TemplateField HeaderText="Download" ItemStyle-CssClass="gridText-left">
                                                <ItemTemplate>
                                                    <asp:LinkButton CssClass="me" ID="btnDownload" runat="server" CausesValidation="false" Text='Download' CommandName="Select" CommandArgument='<%#Bind("Id")%>'></asp:LinkButton>
                                                </ItemTemplate>
                                            </asp:TemplateField>

                                            <asp:TemplateField HeaderText="Action">
                                                <ItemTemplate>
                                                    <asp:LinkButton ID="btnEdit" runat="server" AlternateText="Edit" CommandName="Updates"
                                                        CommandArgument='<%#Bind("Id")%>' CausesValidation="false" data-toggle="tooltip"
                                                        ToolTip="Edit" class="btn btn-xs btn-default">
                                        <i class="fa fa-pencil" style="line-height:inherit;"></i>
                                                    </asp:LinkButton>
                                                    <asp:LinkButton ID="btnDel" runat="server" AlternateText="Delete" CommandName="deletes"
                                                        CommandArgument='<%#Bind("Id")%>' OnClientClick="return confirm('Are you sure you want to delete this Record?');"
                                                        CausesValidation="false" data-toggle="tooltip" ToolTip="Delete" class="btn btn-xs btn-danger">
                                        <i class="fa fa-times" style="line-height:inherit;"></i>
                                                    </asp:LinkButton>
                                                </ItemTemplate>
                                            </asp:TemplateField>
                                        </Columns>
                                    </asp:GridView>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
       
</asp:Content>

