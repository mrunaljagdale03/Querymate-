﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web.UI.WebControls;

public partial class GatePass : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }

    protected void BtnSave_Click(object sender, EventArgs e)
    {
        string pageurl = "PrintGatePass.aspx?vn=" + Encrypt(txtVisitorName.Text) + "&mod=" + Encrypt(txtMobileNumber.Text) + "&con=" + Encrypt(txtContactPersonName.Text) + "&pur=" + Encrypt(txtPurpose.Text);
        Response.Write("<script> window.open('" + pageurl + "', '_blank'); </script>");
    }

    private string Encrypt(string clearText)
    {
        string EncryptionKey = "masterkey";
        byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }
                clearText = Convert.ToBase64String(ms.ToArray());
            }
        }
        return clearText;
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into gatepass values('" + txtVisitorName.Text + "','" + txtMobileNumber.Text + "','" + txtContactPersonName.Text + "','" + txtPurpose.Text + "')", con);
        int result = cmd.ExecuteNonQuery();
        if (result > 0)
        {
            lblmsg.ForeColor = Color.Green;
            lblmsg.Text = "Gate Pass added";

        }

    }

    private void Clear()
    {
        txtVisitorName.Text = "";
        txtMobileNumber.Text = "";
        txtContactPersonName.Text = "";
        txtPurpose.Text = "";
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Clear();
        lblmsg.Text = "";
    }
}