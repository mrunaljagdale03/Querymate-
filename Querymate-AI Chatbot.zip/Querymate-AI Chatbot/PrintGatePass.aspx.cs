﻿using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;

public partial class PrintGatePass : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblVisitorName.Text = Decrypt(Request.QueryString["vn"].ToString());
        lblMobileNumber.Text = Decrypt(Request.QueryString["mod"].ToString());
        lblContactPerson.Text = Decrypt(Request.QueryString["con"].ToString());
        lblPurpose.Text = Decrypt(Request.QueryString["pur"].ToString());
    }
    private string Decrypt(string cipherText)
    {
        string EncryptionKey = "masterkey";
        cipherText = cipherText.Replace(" ", "+");
        byte[] cipherBytes = Convert.FromBase64String(cipherText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(cipherBytes, 0, cipherBytes.Length);
                    cs.Close();
                }
                cipherText = Encoding.Unicode.GetString(ms.ToArray());
            }
        }
        return cipherText;
    }
}