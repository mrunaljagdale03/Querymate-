﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;


/// <summary>
/// Summary description for Password
/// </summary>
public class Password
{
    public Password()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public bool ChangeAdminPassword(string newPassword, int userId)
    {
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString))
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("update AdminLogin set [Password]='" + newPassword + "' where Id='" + userId + "'", connection);
            int result = cmd.ExecuteNonQuery();
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public bool ChangeStudentPassword(string newPassword, int Id)
    {
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString))
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("update StudentRegistration set passwords='" + newPassword + "' where Id='" + Id + "'", connection);
            int result = cmd.ExecuteNonQuery();
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

   

    public bool CheckAdminOldPassword(string oldPassword, int userId)
    {
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString))
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from AdminLogin where [Password]='" + oldPassword + "' and Id='" + userId + "'", connection);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public bool CheckStudentOldPassword(string oldPassword, int Id)
    {
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString))
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from StudentRegistration where passwords='" + oldPassword + "' and Id='" + Id + "'", connection);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

}