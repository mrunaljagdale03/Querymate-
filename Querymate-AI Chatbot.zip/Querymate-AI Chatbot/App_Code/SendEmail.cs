﻿using System.Net;
using System.Net.Mail;

/// <summary>
/// Summary description for SendEmail
/// </summary>
public class SendEmail
{
    public SendEmail()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public void Send(string to,string subject,string body)
    {
        var fromAddress = new MailAddress("querymate.sm3@gmail.com","KKW Poly QueyMate");
        string fromPassword = "mnza pees dguy kgsa";
        var toAddress = new MailAddress(to);

        var smtp = new SmtpClient
        {
            Host = "smtp.gmail.com",
            Port = 587,
            EnableSsl = true,
            DeliveryMethod = SmtpDeliveryMethod.Network,
            UseDefaultCredentials = false,
            Credentials = new NetworkCredential(fromAddress.Address, fromPassword)
        };
        using (var message = new MailMessage(fromAddress, toAddress)
        {
            Subject = subject,
            Body = body
        })
        {
            smtp.Send(message);
        }
    }
}