﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;
/// <summary>
/// Summary description for Login
/// </summary>
public class Login
{
    
    public Login()
    {
      
    }

    public DataTable CheckAdminUser(string email,string password)
    {
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString))
        {
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("select * from AdminLogin where email='" + email + "' and password='" + password + "'", connection);
            DataTable dt = new DataTable();
            sqlDataAdapter.Fill(dt);
            return dt;
        }
    }

    public DataTable CheckStudentUser(string email, string password)
    {
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString))
        {
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("select * from StudentRegistration where email='" + email + "' and Passwords='" + password + "'", connection);
            DataTable dt = new DataTable();
            sqlDataAdapter.Fill(dt);
            return dt;
        }
    }
}