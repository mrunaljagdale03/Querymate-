﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for QuestionAnswer
/// </summary>
public class QuestionAnswer
{
    public QuestionAnswer()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public int Id { get; set; }
    public string Hint1 { get; set; }
    public string Hint2 { get; set; }
    public string Hint3 { get; set; }
    public string Answer { get; set; }
    public string VisitLink { get; set; }


}