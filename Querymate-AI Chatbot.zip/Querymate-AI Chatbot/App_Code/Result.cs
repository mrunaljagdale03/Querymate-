﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Result
/// </summary>
public class Result
{
    public Result()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public int Count { get; set; }
    public string Answer { get; set; }
    public string FileName { get; set; }

}